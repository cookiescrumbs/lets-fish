$(document).ready(function() {
  // If small screen don't load the map JS
  //hide map form mobile before returning
  // if($( window ).width() < 768) {
  //   $('#map').hide();
  //   return;
  // }

  //Remove the server side result list it doesn't always tally with the pins on the map
  //but the server side list is used on mobile becuase this js doesn't load under 768px
  $('#results-container').empty();

  var geocoder = new google.maps.Geocoder(),
  mapOptions = {
    scrollwheel: false,
    mapTypeControlOptions: {
      style: google.maps.MapTypeControlStyle.HORIZONTAL_BAR,
      position: google.maps.ControlPosition.LEFT_BOTTOM,
      mapTypeIds: [
        google.maps.MapTypeId.SATELLITE,
        google.maps.MapTypeId.ROADMAP
      ]
    }
  },
  markers =[],
  mapElement = document.getElementById('map'),
  zoom = getZoom(),
  location = getLocation(),
  lat = getLat(),
  lng = getLng();

  //make the a new instance of google maps
  map = new google.maps.Map(mapElement, mapOptions);


  ///////Search Box
  // Create the search box and link it to the UI element.
  // var input = (document.getElementById('map-search-box'));
  // map.controls[
  //   google.maps.ControlPosition.TOP_LEFT
  // ].push(input);
  // searchBox = new google.maps.places.SearchBox((input));

  // Listen for the event fired when the user selects an item from the
  // pick list. Retrieve the matching places for that item.
  // google.maps.event.addListener(searchBox, 'places_changed', function() {
  //   var places = searchBox.getPlaces();
  //   if (places.length <= 0) {
  //     return;
  //   }
  //   // get the first selected result if there are multiple matches
  //   var firstResult = places[0];
  //   var bounds = new google.maps.LatLngBounds();
  //   bounds.extend(firstResult.geometry.location);
  //   map.fitBounds(bounds);
  //   map.setZoom(10);
  //   boundingBox = getBoundingBoxFromMap(map);
  //   getMarkersAndResultsFromBounds(boundingBox);
  // });
  ///////////////////////////

  ////////Adding markers when map first loads
  google.maps.event.addListenerOnce(map,'idle', function(){
    buildMapRoundLocation(location, function(){
        if($( window ).width() < 768) {
          $('#map').hide();
        }
    });
    buildMapRoundGeographicalCenter(lat,lng, function(){
        if($( window ).width() < 768) {
          $('#map').hide();
        }
    });
    ////////////////////////////
  });

  function getLocation() {
    var location;
    if(!document.getElementById('map').dataset.location && !urlParam('location')) {
      return null;
    }
    location = urlParam('location') ||  mapElement.dataset.location;
    return decodeURIComponent(location);
  }

  function getLat() {
    return parseFloat(mapElement.dataset.lat) || null;
  }

  function getLng() {
    return parseFloat(mapElement.dataset.lng) || null;
  }

  function getZoom() {
    return parseInt(mapElement.dataset.zoom) || 9;
  }

  /////Adding markers when the user zooms the map
  // google.maps.event.addListener(map, 'zoom_changed', function() {
  //   // add markers to map within bounding box
  //   boundingBox = getBoundingBoxFromMap(map);
  //   getMarkersAndResultsFromBounds(boundingBox);
  // });
  ////////////////////////

  ///////Adding markers when the user drags the map
  google.maps.event.addListener(map, 'dragend', function() {
    var boundingBox = getBoundingBoxFromMap(map);
    var center = getCenterFromMap(map);
    getMarkersAndResultsFromBounds(boundingBox, center);
  });
  /////////////////////////

  function buildMapRoundGeographicalCenter(lat, lng, callback) {
      
      if(!lat && !lng) {
        return;
      }

      map.setCenter(new google.maps.LatLng(lat,lng));
      map.setZoom(zoom);
      var boundingBox = getBoundingBoxFromMap(map);
      var center = getCenterFromMap(map);
      getMarkersAndResultsFromBounds(boundingBox, center);

      callback();
  }

  function buildMapRoundLocation(location, callback) {
    
    if(!location) {
      return;
    }

    geocoder.geocode({'address': location}, function(results, status) {
      if (status === google.maps.GeocoderStatus.OK) {
        window.results = results;
        var resultBounds = new google.maps.LatLngBounds(
          results[0].geometry.viewport.getSouthWest(),
          results[0].geometry.viewport.getNorthEast()
        );
        map.fitBounds(resultBounds);
        map.setZoom(zoom);
        var boundingBox = getBoundingBoxFromMap(map);
        var center = getCenterFromMap(map);
        getMarkersAndResultsFromBounds(boundingBox, center);
      } else {
        console.log('Geocode was not successful for the following reason: ' + status);
      }

      callback();
    });
  }

  function getBoundingBoxFromMap(map) {
    var bounds = map.getBounds();
    var northEast  = bounds.getNorthEast();
    var southWest  = bounds.getSouthWest();
    return [southWest.lat(), southWest.lng(), northEast.lat(), northEast.lng()];
  }

  function getCenterFromMap(map){
    if(!map) {
      return;
    }
    return [map.center.lat(), map.center.lng()];
  }

  function addMarkers(data){
    removeAndResetMarkers();
    for (i = 0; i < data.length; i++) {
      var markerCount = i;
      markerCount++;
      var latLng = new google.maps.LatLng(data[i]['lat'],data[i]['lng']);
      var marker = new google.maps.Marker({
        position: latLng,
        icon: data[i].icon + markerCount,
        map: map
      });
      marker.setMap(map);
      markers.push(marker);
    }
  }

  function searchResults(searchResults){
      var  markers = searchResults.markers;
      var results = searchResults.results;
      addMarkers(markers);
      addResultsToPage(results);
  }

  function initialMarkers(searchResults){
    var markers = searchResults.markers;
    addMarkers(markers);
  }

  function addResultsToPage(results){
    var hidden = $('#results-container').is(':hidden');

    $('#results-container').html(results);

    if(hidden) {
      $('#results-container').hide();
    }
  }

  function removeAndResetMarkers() {
    for (var i = 0; i < markers.length; i++) {
        markers[i].setMap(null);
    }
    markers = [];
  }

  function getMarkersAndResultsFromBounds(bounds, center){
    $.ajax({
      type: 'GET',
      url: '/search/within-bounding-box',
      data:{
        'bounds': bounds,
        'center': center
      },
      contentType: "application/json; charset=utf-8",
      dataType: "json",
      success: function(data) {
        searchResults(data);
      },
      failure: function(errMsg) {
          alert(errMsg);
      }
    });
  }

  function urlParam(name){
    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
    if (results==null){
       return null;
    }
    else{
       return results[1] || 0;
    }
  }

});
$(document).ready(function(){

  var markers =[],
  infoWindow = new google.maps.InfoWindow(),
  campsites = document.getElementById('campsites'),
  food = document.getElementById('food'),
  accommodation = document.getElementById('accommodation');
  
  campsites.onclick = function(){
    var lat = map.center.lat();
    var lng = map.center.lng();
    var zoom = map.getZoom();
    getPlaces(lat,lng, 'campground', zoom);
  }

  food.onclick = function(){
    var lat = map.center.lat();
    var lng = map.center.lng();
    var zoom = map.getZoom();
    getPlaces(lat,lng, 'restaurant', zoom);
  }

  drink.onclick = function(){
    var lat = map.center.lat();
    var lng = map.center.lng();
    var zoom = map.getZoom();
    getPlaces(lat,lng, 'bar', zoom);
  }


  accommodation.onclick = function(){
    var lat = map.center.lat();
    var lng = map.center.lng();
    var zoom = map.getZoom();
    getPlaces(lat,lng, 'lodging', zoom);
  }

  function removeAndResetMarkers() {
    for (var i = 0; i < markers.length; i++) {
      markers[i].setMap(null);
    }
    markers = [];
  }
  
  function addMarkers(data){
    removeAndResetMarkers();
    for (i = 0; i < data.length; i++) {
      
      var latLng = new google.maps.LatLng(data[i]['lat'],data[i]['lng']);
      
      var marker = new google.maps.Marker({
        position: latLng,
        icon: '/icons/'+ data[i]['icon'] +'.svg',
        id: data[i]['id'],
        map: map
      });

      google.maps.event.addListener(marker, 'click', function() {
        infoWindow.setContent('...');
        getInfoWindow(this.id);
        infoWindow.open(map, this);
      });

      markers.push(marker);
    }
  }

  function getPlaces(lat, lng, type, zoom){
    console.log(zoom);
    $.ajax({
      type: 'GET',
      url: '/places',
      data:{
        'lat': lat,
        'lng': lng,
        'type': type,
        'zoom': zoom
      },
      contentType: "application/json; charset=utf-8",
      dataType: "json",
      success: function(data){
        addMarkers(data.markers);
      },
      failure: function(errMsg){
        alert(errMsg);
      }
    });
  }

  function getInfoWindow(id){
    $.ajax({
      type: 'GET',
      url: '/places/info-window',
      data:{
        'id': id
      },
      contentType: "application/json; charset=utf-8",
      dataType: "json",
      success: function(data){
        infoWindow.setContent(data.infoWindow);
      },
      failure: function(errMsg){
          alert(errMsg);
      }
    });
  }


});
// This is a manifest file that'll be compiled into application.js, which will include all the files
// listed below.
//
// Any JavaScript/Coffee file within this directory, lib/assets/javascripts, vendor/assets/javascripts,
// or vendor/assets/javascripts of plugins, if any, can be referenced here using a relative path.
//
// It's not advisable to add code directly here, but if you do, it'll appear at the bottom of the
// compiled file.
//
// Read Sprockets README (https://github.com/sstephenson/sprockets#sprockets-directives) for details
// about supported directives.


;
